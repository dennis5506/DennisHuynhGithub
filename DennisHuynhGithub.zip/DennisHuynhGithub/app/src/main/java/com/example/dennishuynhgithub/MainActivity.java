package com.example.dennishuynhgithub;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.gson.annotations.SerializedName;
import com.squareup.picasso.Picasso;

import android.content.Context;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;

public class MainActivity extends AppCompatActivity {

    class Setup{
        @SerializedName("id")
        private int id;
        @SerializedName("login")
        private String login;
        @SerializedName("avatar_url")
        private String avatar;
        @SerializedName("url")
        private String url;

        public Setup(int id, String login, String avatar, String url) {
            this.id = id;
            this.login = login;
            this.avatar = avatar;
            this.url = url;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getLogin() {
            return login;
        }

        public void setLogin(String login) {
            this.login = login;
        }

        public String getAvatar() {
            return avatar;
        }

        public void setAvatar(String avatar) {
            this.avatar = avatar;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }
    }

    interface MyAPIService{
        @GET("/users?since")
        Call<List<Setup>> getSetup();
    }

    static class RetrofitClientInstance{
        private static Retrofit retrofit;
        private static final String API = "https://api.github.com/";

        public static Retrofit getRetrofitInstance(){
            if(retrofit == null){
                retrofit = new Retrofit.Builder()
                        .baseUrl(API)
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();
            }
            return retrofit;
        }
    }

    class GridViewAdapter extends BaseAdapter {
        private List<Setup> setups;
        private Context context;

        public GridViewAdapter(Context context, List<Setup> setups){
            this.context = context;
            this.setups = setups;
        }

        @Override
        public int getCount(){
            return setups.size();
        }

        @Override
        public Object getItem(int pos){
            return setups.get(pos);
        }

        @Override
        public long getItemId(int pos){
            return pos;
        }

        @Override
        public View getView(int position, View view, ViewGroup viewGroup){
            if(view == null){
                view = LayoutInflater.from(context).inflate(R.layout.layout_row, viewGroup, false);
            }
            TextView textView = view.findViewById(R.id.textView);
            TextView textView2 = view.findViewById(R.id.textView2);
            TextView textView3 = view.findViewById(R.id.textView3);
            ImageView imageView = view.findViewById(R.id.imageView);

            final Setup setup = setups.get(position);

            textView.setText(setup.getLogin());
            textView2.setText(setup.getUrl());
            textView3.setText(String.valueOf(setup.getId()));
            Picasso.get().load(setup.getAvatar()).into(imageView);

            return view;
        }
    }

    private GridViewAdapter gridViewAdapter;
    private GridView gridView;
    ProgressBar progressBar;

    private void populate(List<Setup> setups){
        gridView = findViewById(R.id.gridView);
        gridViewAdapter = new GridViewAdapter(this,setups);
        gridView.setAdapter(gridViewAdapter);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final ProgressBar myProgressBar = findViewById(R.id.progressBar);
        myProgressBar.setIndeterminate(true);
        myProgressBar.setVisibility(View.VISIBLE);

        MyAPIService myAPIService = RetrofitClientInstance.getRetrofitInstance().create(MyAPIService.class);

        Call<List<Setup>> call = myAPIService.getSetup();
        call.enqueue(new Callback<List<Setup>>() {
            @Override
            public void onResponse(Call<List<Setup>> call, Response<List<Setup>> response) {
                myProgressBar.setVisibility(View.GONE);
                populate(response.body());
            }

            @Override
            public void onFailure(Call<List<Setup>> call, Throwable t) {
                myProgressBar.setVisibility(View.GONE);
                Toast.makeText(MainActivity.this,t.getMessage(), Toast.LENGTH_LONG);
            }
        });
    }
}